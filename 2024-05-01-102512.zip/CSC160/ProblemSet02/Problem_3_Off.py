x = 155
print(f"x = {x:b}")
n = 1
y = x & ~(1<<n) 
print(f"y = {y:b}")